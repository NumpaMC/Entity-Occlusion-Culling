package com.NumpaMC.mixin;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.class_761;
import net.minecraft.class_846;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_761.class)
public interface WorldRendererAccessor {

    @Accessor("builtChunks")
    ObjectArrayList<class_846.class_851> getBuiltChunks();

    @Accessor("builtChunks")
    void setBuiltChunks(ObjectArrayList<class_846.class_851> builtChunks);
}
