package yt.Numpamc.frustumcullingentity.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BlockRenderLayer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import yt.Numpamc.frustumcullingentity.CacheEntry;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.WeakHashMap;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin<T extends LivingEntity> {

    @Unique private static final double MAX_RENDER_DISTANCE = 110.0;
    @Unique private static final double NEAR_BLOCK_DISTANCE = 1.0;
    @Unique private static final long CACHE_DURATION_MS = 250L;

    @Unique private final Map<T, CacheEntry> visibilityCache = new WeakHashMap<>();
    @Unique private final Map<LivingEntityRenderState, T> stateToEntity = new WeakHashMap<>();

    // --- Update render state ---
    @Inject(method = "updateRenderState*", at = @At("HEAD"))
    private void onUpdateRenderState(T entity, LivingEntityRenderState state, float tickDelta, CallbackInfo ci) {
        if (entity == null) return;

        stateToEntity.put(state, entity);

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.gameRenderer == null || client.world == null) return;

        Box box = entity.getBoundingBox();
        Vec3d center = box.getCenter();
        double distSq = client.gameRenderer.getCamera().getPos().squaredDistanceTo(center);

        if (distSq > MAX_RENDER_DISTANCE * MAX_RENDER_DISTANCE) {
            visibilityCache.put(entity, new CacheEntry(false, System.currentTimeMillis(), center, box));
            return;
        }

        CacheEntry cached = visibilityCache.get(entity);
        long now = System.currentTimeMillis();
        if (isCacheValid(cached, center, box, now)) return;

        boolean visible = computeVisibility(client, client.gameRenderer.getCamera().getPos(), box, center, entity);
        visibilityCache.put(entity, new CacheEntry(visible, now, center, box));
    }

    // --- Pre render check ---
    @Inject(method = "render*", at = @At("HEAD"), cancellable = true)
    private void preRender(LivingEntityRenderState state,
                           MatrixStack matrices,
                           OrderedRenderCommandQueue queue,
                           CameraRenderState cameraState,
                           CallbackInfo ci) {

        T entity = stateToEntity.get(state);
        if (entity == null) {
            entity = extractEntityFromState(state);
            if (entity == null) return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.gameRenderer == null || client.world == null) return;

        Box box = entity.getBoundingBox();
        Vec3d center = box.getCenter();
        CacheEntry cached = visibilityCache.get(entity);
        long now = System.currentTimeMillis();

        if (isCacheValid(cached, center, box, now)) {
            if (!cached.visible) ci.cancel();
            return;
        }

        Camera camera = client.gameRenderer.getCamera();
        Vec3d camPos = camera.getPos();
        double distSq = camPos.squaredDistanceTo(center);

        if (distSq > MAX_RENDER_DISTANCE * MAX_RENDER_DISTANCE) {
            visibilityCache.put(entity, new CacheEntry(false, now, center, box));
            ci.cancel();
            return;
        }

        boolean visible = computeVisibility(client, camPos, box, center, entity);
        visibilityCache.put(entity, new CacheEntry(visible, now, center, box));
        if (!visible) ci.cancel();
    }

    // --- Visibility helpers ---
    @Unique

    private boolean computeVisibility(MinecraftClient client, Vec3d camPos, Box box, Vec3d center, LivingEntity entity) {
        if (client.player == null || client.world == null) return true;

        double[] heights = new double[] { box.minY + 0.05, box.getCenter().y, box.maxY - 0.05 };

        for (double y : heights) {
            Vec3d[] points = new Vec3d[]{
                    new Vec3d(box.getCenter().x, y, box.getCenter().z),
                    new Vec3d(box.minX, y, box.minZ),
                    new Vec3d(box.maxX, y, box.maxZ)
            };

            for (Vec3d target : points) {
                RaycastContext ctx = new RaycastContext(camPos, target,
                        RaycastContext.ShapeType.OUTLINE,
                        RaycastContext.FluidHandling.NONE,
                        client.player);

                HitResult hr = client.world.raycast(ctx);
                if (hr == null || hr.getType() != HitResult.Type.BLOCK) return true;

                if (hr instanceof BlockHitResult bhr) {
                    BlockState state = client.world.getBlockState(bhr.getBlockPos());
                    if (!isCullableBlock(client, bhr.getBlockPos(), state)) return true;
                } else return true;
            }
        }

        return false;
    }


    @Unique
    private boolean isCullableBlock(MinecraftClient client, BlockPos pos, BlockState state) {
        try {
            if (!state.isOpaqueFullCube()) return false;
        } catch (Exception ignored) {
            return false;
        }

        try {
            BlockRenderLayer layer = RenderLayers.getBlockLayer(state);
            return !(layer == BlockRenderLayer.CUTOUT
                    || layer == BlockRenderLayer.CUTOUT_MIPPED
                    || layer == BlockRenderLayer.TRANSLUCENT);
        } catch (Exception ignored) {
            return true;
        }
    }

    @Unique
    private boolean isCacheValid(CacheEntry cached, Vec3d center, Box box, long now) {
        if (cached == null) return false;

        double moved = cached.lastPos == null ? Double.MAX_VALUE : cached.lastPos.squaredDistanceTo(center);
        double boxChanged = cached.lastBox == null ? Double.MAX_VALUE :
                Math.abs(cached.lastBox.getLengthX() - box.getLengthX()) +
                        Math.abs(cached.lastBox.getLengthY() - box.getLengthY()) +
                        Math.abs(cached.lastBox.getLengthZ() - box.getLengthZ());

        return (now - cached.lastCheck < CACHE_DURATION_MS) &&
                moved < NEAR_BLOCK_DISTANCE &&
                boxChanged < 0.01;
    }

    @Unique
    @SuppressWarnings("unchecked")
    private T extractEntityFromState(LivingEntityRenderState state) {
        if (state == null) return null;

        String[] getters = {"getLivingEntity", "getEntity", "getOwner", "getRenderedEntity"};
        for (String g : getters) {
            try {
                Method m = state.getClass().getMethod(g);
                m.setAccessible(true);
                Object o = m.invoke(state);
                if (o instanceof LivingEntity) return (T) o;
            } catch (Exception ignored) {}
        }

        String[] fields = {"livingEntity", "entity", "owner", "renderedEntity"};
        for (String fName : fields) {
            try {
                Field f = state.getClass().getDeclaredField(fName);
                f.setAccessible(true);
                Object o = f.get(state);
                if (o instanceof LivingEntity) return (T) o;
            } catch (Exception ignored) {}
        }

        try {
            for (Field f : state.getClass().getDeclaredFields()) {
                f.setAccessible(true);
                Object o = f.get(state);
                if (o instanceof LivingEntity) return (T) o;
            }
        } catch (Exception ignored) {}

        return null;
    }
}
