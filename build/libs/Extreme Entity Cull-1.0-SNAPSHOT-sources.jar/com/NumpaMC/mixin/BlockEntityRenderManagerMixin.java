package com.NumpaMC.mixin;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import net.minecraft.class_846;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class BlockEntityRenderManagerMixin {

    private static final int SAFE_RADIUS_SECTIONS = 1;   // Chỉ giữ chunk cực gần người chơi
    private static final int GUARD_BAND_SECTIONS = 0;    // Không đệm gì cả

    // Throttle: cull mỗi ~150ms để cân bằng giữa hiệu năng và phản hồi nhanh
    private static long lastCullTime = 0;
    private static final long CULL_INTERVAL_MS = 150;

    @Inject(method = "render", at = @At("TAIL"))
    private void bura$aggressiveChunkCulling(CallbackInfo ci) {
        long now = System.currentTimeMillis();
        if (now - lastCullTime < CULL_INTERVAL_MS) {
            return;
        }
        lastCullTime = now;

        class_761 wr = (class_761) (Object) this;
        class_4604 frustum = wr.method_62222();
        if (frustum == null) return;

        WorldRendererAccessor accessor = (WorldRendererAccessor) (Object) this;
        ObjectArrayList<class_846.class_851> visible = accessor.getBuiltChunks();
        if (visible == null || visible.isEmpty()) return;

        class_4184 camera = class_310.method_1551().field_1773.method_19418();
        class_243 camPos = camera.method_71156();           // giữ theo mapping của bạn
        class_2338 camBlock = class_2338.method_49638(camPos);

        ObjectArrayList<class_846.class_851> filtered = new ObjectArrayList<>(visible.size());

        for (class_846.class_851 chunk : visible) {
            class_2338 origin = chunk.method_3670();

            int dx = (origin.method_10263() - camBlock.method_10263()) >> 4;
            int dy = (origin.method_10264() - camBlock.method_10264()) >> 4;
            int dz = (origin.method_10260() - camBlock.method_10260()) >> 4;

            // 1. Chunk cực gần → luôn giữ (tránh pop-in ngay sát người chơi)
            if (Math.abs(dx) <= SAFE_RADIUS_SECTIONS &&
                    Math.abs(dy) <= SAFE_RADIUS_SECTIONS &&
                    Math.abs(dz) <= SAFE_RADIUS_SECTIONS) {
                filtered.add(chunk);
                continue;
            }

            // 2. Chunk xa → chỉ giữ nếu Frustum nói VISIBLE (sau lưng, bị block chắn, ngoài góc nhìn → cull hết)
            boolean visibleInFrustum = frustum.method_23093(chunk.method_40051());

            if (visibleInFrustum) {
                filtered.add(chunk);
            }
        }

        accessor.setBuiltChunks(filtered);
    }
}
