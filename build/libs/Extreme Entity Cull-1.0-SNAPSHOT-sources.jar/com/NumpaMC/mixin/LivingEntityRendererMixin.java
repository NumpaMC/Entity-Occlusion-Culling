package com.NumpaMC.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.NumpaMC.CacheEntry;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1309;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_922;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin<T extends class_1309> {

    @Unique private static final double MAX_RENDER_DISTANCE = 110.0;
    @Unique private static final double NEAR_BLOCK_DISTANCE = 1.0;
    @Unique private static final long CACHE_DURATION_MS = 300L;

    @Unique private final Map<T, CacheEntry> visibilityCache = new WeakHashMap<>();
    @Unique private final Map<class_10042, T> stateToEntity = new WeakHashMap<>();

    @Inject(
            method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
            at = @At("HEAD")
    )
    private void onUpdateRenderState(T livingEntity,
                                     class_10042 livingEntityRenderState,
                                     float f,
                                     CallbackInfo ci) {
        if (livingEntity == null) return;

        stateToEntity.put(livingEntityRenderState, livingEntity);

        class_310 client = class_310.method_1551();
        if (client == null || client.field_1773 == null || client.field_1687 == null) return;

        class_238 box = livingEntity.method_5829();
        class_243 center = box.method_1005();
        class_243 camPos = client.field_1773.method_19418().method_71156();
        double distSq = camPos.method_1025(center);

        if (distSq > MAX_RENDER_DISTANCE * MAX_RENDER_DISTANCE) {
            visibilityCache.put(livingEntity, new CacheEntry(false, System.currentTimeMillis(), center, box));
            return;
        }

        CacheEntry cached = visibilityCache.get(livingEntity);
        long now = System.currentTimeMillis();
        if (isCacheValid(cached, center, box, now)) return;

        boolean visible = computeVisibility(client, camPos, box);
        visibilityCache.put(livingEntity, new CacheEntry(visible, now, center, box));
    }

    @Inject(
            method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void preRender(class_10042 livingEntityRenderState,
                           class_4587 matrixStack,
                           class_11659 orderedRenderCommandQueue,
                           class_12075 cameraRenderState,
                           CallbackInfo ci) {

        T livingEntity = stateToEntity.get(livingEntityRenderState);
        if (livingEntity == null) {
            livingEntity = extractEntityFromState(livingEntityRenderState);
            if (livingEntity == null) return;
        }

        class_310 client = class_310.method_1551();
        if (client == null || client.field_1773 == null || client.field_1687 == null) return;

        class_238 box = livingEntity.method_5829();
        class_243 center = box.method_1005();
        CacheEntry cached = visibilityCache.get(livingEntity);
        long now = System.currentTimeMillis();

        if (isCacheValid(cached, center, box, now)) {
            if (!cached.visible) ci.cancel();
            return;
        }

        class_4184 camera = client.field_1773.method_19418();
        class_243 camPos = camera.method_71156();
        double distSq = camPos.method_1025(center);

        if (distSq > MAX_RENDER_DISTANCE * MAX_RENDER_DISTANCE) {
            visibilityCache.put(livingEntity, new CacheEntry(false, now, center, box));
            ci.cancel();
            return;
        }

        boolean visible = computeVisibility(client, camPos, box);
        visibilityCache.put(livingEntity, new CacheEntry(visible, now, center, box));
        if (!visible) ci.cancel();
    }

    @Unique
    private boolean computeVisibility(class_310 client, class_243 camPos, class_238 box) {
        if (client.field_1724 == null || client.field_1687 == null) return true;

        double[] heights = new double[] { box.field_1322 + 0.05, box.method_1005().field_1351, box.field_1325 - 0.05 };

        for (double y : heights) {
            class_243[] points = new class_243[] {
                    new class_243(box.method_1005().field_1352, y, box.method_1005().field_1350),
                    new class_243(box.field_1323, y, box.field_1321),
                    new class_243(box.field_1320, y, box.field_1324)
            };

            for (class_243 target : points) {
                class_3959 ctx = new class_3959(
                        camPos,
                        target,
                        class_3959.class_3960.field_17559,
                        class_3959.class_242.field_1348,
                        client.field_1724
                );

                class_239 hr = client.field_1687.method_17742(ctx);
                if (hr == null || hr.method_17783() != class_239.class_240.field_1332) return true;

                if (hr instanceof class_3965 bhr) {
                    class_2680 state = client.field_1687.method_8320(bhr.method_17777());
                    if (!isCullableBlock(state)) return true;
                } else {
                    return true;
                }
            }
        }

        return false;
    }

    @Unique
    private boolean isCullableBlock(class_2680 state) {
        if (state == null) return false;

        try {
            if (state.method_26217() != class_2464.field_11458) {
                return false;
            }
        } catch (Throwable ignored) {
            return false;
        }

        try {
            return state.method_26216();
        } catch (Throwable ignored) {
            return false;
        }
    }

    @Unique
    private boolean isCacheValid(CacheEntry cached, class_243 center, class_238 box, long now) {
        if (cached == null) return false;

        double moved = cached.lastPos == null ? Double.MAX_VALUE : cached.lastPos.method_1025(center);
        double boxChanged = cached.lastBox == null ? Double.MAX_VALUE :
                Math.abs(cached.lastBox.method_17939() - box.method_17939()) +
                        Math.abs(cached.lastBox.method_17940() - box.method_17940()) +
                        Math.abs(cached.lastBox.method_17941() - box.method_17941());

        return (now - cached.lastCheck < CACHE_DURATION_MS)
                && moved < NEAR_BLOCK_DISTANCE
                && boxChanged < 0.01;
    }

    @Unique
    @SuppressWarnings("unchecked")
    private T extractEntityFromState(class_10042 state) {
        if (state == null) return null;

        String[] getters = {"getLivingEntity", "getEntity", "getOwner", "getRenderedEntity"};
        for (String g : getters) {
            try {
                Method m = state.getClass().getMethod(g);
                m.setAccessible(true);
                Object o = m.invoke(state);
                if (o instanceof class_1309) return (T) o;
            } catch (Exception ignored) {}
        }

        String[] fields = {"livingEntity", "entity", "owner", "renderedEntity"};
        for (String fName : fields) {
            try {
                Field f = state.getClass().getDeclaredField(fName);
                f.setAccessible(true);
                Object o = f.get(state);
                if (o instanceof class_1309) return (T) o;
            } catch (Exception ignored) {}
        }

        try {
            for (Field f : state.getClass().getDeclaredFields()) {
                f.setAccessible(true);
                Object o = f.get(state);
                if (o instanceof class_1309) return (T) o;
            }
        } catch (Exception ignored) {}

        return null;
    }
}