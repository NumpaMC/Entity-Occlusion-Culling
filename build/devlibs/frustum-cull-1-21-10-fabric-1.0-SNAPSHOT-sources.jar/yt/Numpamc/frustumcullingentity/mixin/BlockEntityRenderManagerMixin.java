package yt.Numpamc.frustumcullingentity.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.block.entity.BlockEntityRenderManager;
import net.minecraft.client.render.block.entity.state.BlockEntityRenderState;
import net.minecraft.client.render.command.ModelCommandRenderer;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import yt.Numpamc.frustumcullingentity.CacheEntry;

import java.util.Map;
import java.util.WeakHashMap;

@Mixin(BlockEntityRenderManager.class)
public abstract class BlockEntityRenderManagerMixin {

    @Unique private static final double MAX_RENDER_DISTANCE = 110.0;
    @Unique private static final long CACHE_DURATION_MS = 250L;

    @Unique private final Map<BlockEntity, CacheEntry> visibilityCache = new WeakHashMap<>();

    @Inject(method = "getRenderState", at = @At("HEAD"), cancellable = true)
    private <E extends BlockEntity, S extends BlockEntityRenderState> void onGetRenderState(
            E blockEntity,
            float tickProgress,
            ModelCommandRenderer.CrumblingOverlayCommand crumblingOverlay,
            CallbackInfoReturnable<S> cir
    ) {
        if (blockEntity == null || !blockEntity.hasWorld()) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.world == null || client.gameRenderer == null) return;

        BlockPos pos = blockEntity.getPos();
        Box box = new Box(pos); // có thể mở rộng nếu block entity lớn
        Vec3d center = box.getCenter();
        long now = System.currentTimeMillis();
        CacheEntry cached = visibilityCache.get(blockEntity);

        if (isCacheValid(cached, center, box, now)) {
            if (!cached.visible) cir.setReturnValue(null);
            return;
        }

        Vec3d cameraPos = client.gameRenderer.getCamera().getPos();
        double distSq = cameraPos.squaredDistanceTo(center);

        if (distSq > MAX_RENDER_DISTANCE * MAX_RENDER_DISTANCE) {
            visibilityCache.put(blockEntity, new CacheEntry(false, now, center, box));
            cir.setReturnValue(null);
            return;
        }

        boolean visible = computeVisibility(client, cameraPos, box, center);
        visibilityCache.put(blockEntity, new CacheEntry(visible, now, center, box));
        if (!visible) cir.setReturnValue(null);
    }

    @Unique
    private boolean computeVisibility(MinecraftClient client, Vec3d cameraPos, Box box, Vec3d center) {
        Vec3d[] points = getVec3ds(box, center);

        for (Vec3d target : points) {
            if (client.player == null || client.world == null) return true;

            RaycastContext ctx = new RaycastContext(
                    cameraPos,
                    target,
                    RaycastContext.ShapeType.OUTLINE,
                    RaycastContext.FluidHandling.NONE,
                    client.player
            );

            HitResult hr = client.world.raycast(ctx);
            if (hr == null || hr.getType() != HitResult.Type.BLOCK) return true;

            if (hr instanceof BlockHitResult bhr) {
                BlockState state = client.world.getBlockState(bhr.getBlockPos());
                if (!isCullableBlock(state)) return true;
            } else return true;
        }

        return false;
    }

    @Unique
    private static Vec3d @NotNull [] getVec3ds(Box box, Vec3d center) {
        Vec3d[] points;
        if (box.getLengthX() > 1 || box.getLengthY() > 1 || box.getLengthZ() > 1) {
            points = new Vec3d[]{
                    center,
                    new Vec3d(box.minX, box.minY, box.minZ),
                    new Vec3d(box.maxX, box.maxY, box.maxZ),
            };
        } else {
            points = new Vec3d[]{center, new Vec3d(box.minX, box.minY, box.minZ)};
        }
        return points;
    }

    @Unique
    private boolean isCullableBlock(BlockState state) {
        if (state == null) return false;
        try {
            if (!state.isOpaqueFullCube()) return false;
        } catch (Exception ignored) {
            return false;
        }

        try {
            return !(RenderLayers.getBlockLayer(state) == net.minecraft.client.render.BlockRenderLayer.CUTOUT
                    || RenderLayers.getBlockLayer(state) == net.minecraft.client.render.BlockRenderLayer.CUTOUT_MIPPED
                    || RenderLayers.getBlockLayer(state) == net.minecraft.client.render.BlockRenderLayer.TRANSLUCENT);
        } catch (Exception ignored) {
            return true;
        }
    }

    @Unique
    private boolean isCacheValid(CacheEntry cached, Vec3d center, Box box, long now) {
        if (cached == null) return false;

        double moved = cached.lastPos == null ? Double.MAX_VALUE : cached.lastPos.squaredDistanceTo(center);
        double boxChanged = cached.lastBox == null ? Double.MAX_VALUE :
                Math.abs(cached.lastBox.getLengthX() - box.getLengthX()) +
                        Math.abs(cached.lastBox.getLengthY() - box.getLengthY()) +
                        Math.abs(cached.lastBox.getLengthZ() - box.getLengthZ());

        return (now - cached.lastCheck < CACHE_DURATION_MS) &&
                moved < 0.5 &&
                boxChanged < 0.01;
    }
}
