package com.NumpaMC;

import net.minecraft.class_238;
import net.minecraft.class_243;

public class CacheEntry {
    public final boolean visible;
    public final long lastCheck;
    public final class_243 lastPos;
    public final class_238 lastBox;

    public CacheEntry(boolean visible, long lastCheck, class_243 lastPos, class_238 lastBox) {
        this.visible = visible;
        this.lastCheck = lastCheck;
        this.lastPos = lastPos;
        this.lastBox = lastBox;
    }
}
